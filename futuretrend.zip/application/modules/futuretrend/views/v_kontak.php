<section class="contact spad py-5">
    <div class="container">
        <div class="row g-5">
            <!-- Contact Info & Form -->
            <div class="col-lg-6">
                <div class="contact__content">
                    <!-- Contact Info -->
                    <div class="contact__address mb-5">
                        <h4 class="mb-4">Contact Info</h4>
                        <ul class="list-unstyled">
                            <li class="mb-3">
                                <h6><i class="fa fa-map-marker me-2 text-primary"></i> Address</h6>
                                <p class="text-muted">160 Pennsylvania Ave NW, Washington, Castle, PA 16101-5161</p>
                            </li>
                            <li class="mb-3">
                                <h6><i class="fa fa-phone me-2 text-primary"></i> Phone</h6>
                                <p class="text-muted">
                                    <span class="d-block">125-711-811</span>
                                    <span class="d-block">125-668-886</span>
                                </p>
                            </li>
                            <li class="mb-3">
                                <h6><i class="fa fa-headphones me-2 text-primary"></i> Support</h6>
                                <p class="text-muted">
                                    <a href="#" class="text-decoration-none">[email&#160;protected]</a>
                                </p>
                            </li>
                        </ul>
                    </div>

                    <!-- Contact Form -->
                    <div class="contact__form">
                        <h4 class="mb-4">Send Message</h4>
                        <form action="#" class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control" placeholder="Name" required>
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="form-control" placeholder="Email" required>
                            </div>
                            <div class="col-12">
                                <input type="text" class="form-control" placeholder="Website">
                            </div>
                            <div class="col-12">
                                <textarea class="form-control" rows="5" placeholder="Message" required></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary px-4 py-2">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Map -->
            <div class="col-lg-6">
                <div class="contact__map h-100">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d48158.305462977965!2d-74.13283844036356!3d41.02757295168286!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2e440473470d7%3A0xcaf503ca2ee57958!2sSaddle%20River%2C%20NJ%2007458%2C%20USA!5e0!3m2!1sen!2sbd!4v1575917275626!5m2!1sen!2sbd"
                        width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy">
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</section>
